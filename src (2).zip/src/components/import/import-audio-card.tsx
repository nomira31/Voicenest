import { useAppDialog } from "@/components/ui/app-dialog";
import {
    Fonts,
    Radius,
    Shadows,
    Spacing,
    Typography,
    useAppTheme,
    type Theme,
} from "@/constants/theme";
import { useRecordings } from "@/contexts/recordings-context";
import {
    extractHttpsUrl,
    importDirectAudioUrl,
    saveAudioImport,
} from "@/lib/audio/import-recording";
import Ionicons from "@expo/vector-icons/Ionicons";
import * as DocumentPicker from "expo-document-picker";
import { useState } from "react";
import {
    ActivityIndicator,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    useColorScheme,
} from "react-native";

export type ImportAudioCardProps = {
  onImportComplete?: () => void;
};

export function ImportAudioCard({ onImportComplete }: ImportAudioCardProps) {
  const colors = useAppTheme();
  const isDark = useColorScheme() === "dark";
  const styles = createStyles(colors, isDark);

  const { addRecording } = useRecordings();
  const { dialog, showAlert, showOptions, showPrompt } = useAppDialog();
  const [isImporting, setIsImporting] = useState(false);

  async function handleImportAudio() {
    if (isImporting) return;

    const choice = await showOptions(
      "Import Audio",
      "Select where you want to import your audio recording from:",
      [
        {
          label: "Choose audio file",
          value: "file",
          icon: "document-text-outline",
        },
        {
          label: "Import from direct link",
          value: "url",
          icon: "link-outline",
        },
      ]
    );

    if (!choice) return;

    if (choice === "file") {
      try {
        const result = await DocumentPicker.getDocumentAsync({
          type: [
            "audio/*",
            "audio/mpeg",
            "audio/mp4",
            "audio/x-m4a",
            "audio/wav",
            "audio/aac",
            "audio/ogg",
          ],
          copyToCacheDirectory: true,
        });

        if (result.canceled || !result.assets || result.assets.length === 0) {
          return;
        }

        const pickedFile = result.assets[0];
        setIsImporting(true);

        await saveAudioImport(
          {
            uri: pickedFile.uri,
            name: pickedFile.name,
            mimeType: pickedFile.mimeType ?? undefined,
            sizeBytes: pickedFile.size ?? undefined,
          },
          addRecording
        );

        void showAlert(
          "Audio imported",
          `"${pickedFile.name}" has been added to your VoiceNest library.`
        );
        onImportComplete?.();
      } catch (error) {
        void showAlert(
          "Import failed",
          error instanceof Error ? error.message : "Could not import the selected audio file."
        );
      } finally {
        setIsImporting(false);
      }
    } else if (choice === "url") {
      const inputUrl = await showPrompt(
        "Import from Link",
        "Enter a direct URL to an audio file (.mp3, .m4a, .wav):",
        "",
        "https://example.com/audio.mp3"
      );

      if (!inputUrl) return;

      const directUrl = extractHttpsUrl(inputUrl) || inputUrl.trim();
      setIsImporting(true);

      try {
        await importDirectAudioUrl(directUrl, addRecording);
        void showAlert(
          "Audio imported",
          "The audio file was downloaded and added to your VoiceNest library."
        );
        onImportComplete?.();
      } catch (error) {
        void showAlert(
          "Import failed",
          error instanceof Error
            ? error.message
            : "The link provided is not a valid direct audio download."
        );
      } finally {
        setIsImporting(false);
      }
    }
  }

  return (
    <>
      <TouchableOpacity
        style={[styles.quickCard, { backgroundColor: colors.surfaceSage }]}
        onPress={handleImportAudio}
        activeOpacity={0.8}
        disabled={isImporting}
        accessibilityRole="button"
        accessibilityLabel="Import audio"
      >
        <View style={[styles.quickIcon, { backgroundColor: colors.backgroundElevated }]}>
          {isImporting ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Ionicons name="cloud-download-outline" size={20} color={colors.primary} />
          )}
        </View>
        <View style={styles.quickText}>
          <Text style={styles.quickTitle}>
            {isImporting ? "Importing..." : "Import audio"}
          </Text>
          <Text style={styles.quickCaption}>
            {isImporting ? "Please wait" : "Keep it all close"}
          </Text>
        </View>
      </TouchableOpacity>
      {dialog}
    </>
  );
}

function createStyles(colors: Theme, isDark: boolean) {
  const cardShadow = isDark ? Shadows.dark.card : Shadows.light.card;

  return StyleSheet.create({
    quickCard: {
      width: "48.5%",
      minHeight: 84,
      paddingHorizontal: Spacing.three,
      paddingVertical: Spacing.three,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      gap: Spacing.two,
      borderWidth: 1,
      borderColor: colors.border,
      ...cardShadow,
    },
    quickIcon: {
      width: 38,
      height: 38,
      borderRadius: Radius.sm,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.border,
    },
    quickText: {
      flex: 1,
      minWidth: 0,
      justifyContent: "center",
    },
    quickTitle: {
      ...Typography.caption,
      fontFamily: Fonts?.sans,
      fontWeight: "700",
      fontSize: 12,
      lineHeight: 16,
      color: colors.textPrimary,
    },
    quickCaption: {
      ...Typography.caption,
      fontFamily: Fonts?.sans,
      fontSize: 10,
      lineHeight: 14,
      marginTop: 2,
      color: colors.textSecondary,
    },
  });
}