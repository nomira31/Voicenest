import { useAppDialog } from "@/components/ui/app-dialog";
import {
    Fonts,
    Radius,
    Shadows,
    Spacing,
    Typography,
    useAppTheme,
    useResponsiveLayout,
    type Theme
} from "@/constants/theme";
import { useRecordings } from "@/contexts/recordings-context";
import {
    extractHttpsUrl,
    importDirectAudioUrl,
    saveAudioImport,
} from "@/lib/audio/import-recording";
import Ionicons from "@expo/vector-icons/Ionicons";
import * as DocumentPicker from "expo-document-picker";
import { useEffect, useMemo, useRef, useState } from "react";
import {
    Animated,
    Easing,
    Modal,
    Pressable,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    useColorScheme,
    type StyleProp,
    type ViewStyle,
} from "react-native";

export type ImportAudioCardProps = {
  onImportComplete?: () => void;
  style?: StyleProp<ViewStyle>;
};

const WAVE_BAR_HEIGHTS = [14, 26, 40, 52, 42, 28, 16, 34, 46, 24, 14];

const IMPORT_STEPS = [
  {
    title: "Reading audio stream",
    subtitle: "Inspecting file container and audio channels...",
    icon: "document-Lock-outline" as const,
  },
  {
    title: "Processing waveform",
    subtitle: "Preparing high-clarity playback for your library...",
    icon: "pulse-outline" as const,
  },
  {
    title: "Saving to VoiceNest",
    subtitle: "Securing your voice moment in local storage...",
    icon: "sparkles-outline" as const,
  },
];

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function ImportAudioCard({ onImportComplete, style }: ImportAudioCardProps) {
  const colors = useAppTheme();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const responsive = useResponsiveLayout();
  const styles = createStyles(colors, isDark, responsive);

  const { addRecording } = useRecordings();
  const { dialog, showAlert, showOptions, showPrompt } = useAppDialog();

  const [isImporting, setIsImporting] = useState(false);
  const [importLabel, setImportLabel] = useState("");
  const [importSourceType, setImportSourceType] = useState<"file" | "url">("file");
  const [stepIndex, setStepIndex] = useState(0);
  const [boostCount, setBoostCount] = useState(0);

  const waveValues = useMemo(
    () => WAVE_BAR_HEIGHTS.map(() => new Animated.Value(0.35)),
    [],
  );
  const ringAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;
  const cardScaleAnim = useRef(new Animated.Value(0.92)).current;
  const cardOpacityAnim = useRef(new Animated.Value(0)).current;
  const orbBounceAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (!isImporting) {
      cardScaleAnim.setValue(0.92);
      cardOpacityAnim.setValue(0);
      progressAnim.setValue(0);
      ringAnim.setValue(0);
      setStepIndex(0);
      setBoostCount(0);
      return;
    }

    Animated.parallel([
      Animated.spring(cardScaleAnim, {
        toValue: 1,
        damping: 16,
        stiffness: 180,
        useNativeDriver: true,
      }),
      Animated.timing(cardOpacityAnim, {
        toValue: 1,
        duration: 220,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(progressAnim, {
        toValue: 0.92,
        duration: 2400,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: false,
      }),
    ]).start();

    const ringLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(ringAnim, {
          toValue: 1,
          duration: 1500,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(ringAnim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ]),
    );
    ringLoop.start();

    const waveLoops = waveValues.map((anim, index) => {
      const cycleDuration = 320 + (index % 4) * 90;
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(anim, {
            toValue: 1,
            duration: cycleDuration,
            delay: index * 45,
            easing: Easing.inOut(Easing.sin),
            useNativeDriver: true,
          }),
          Animated.timing(anim, {
            toValue: 0.28,
            duration: cycleDuration,
            easing: Easing.inOut(Easing.sin),
            useNativeDriver: true,
          }),
        ]),
      );
      loop.start();
      return loop;
    });

    const stepInterval = setInterval(() => {
      setStepIndex((prev) => (prev < IMPORT_STEPS.length - 1 ? prev + 1 : prev));
    }, 650);

    return () => {
      ringLoop.stop();
      waveLoops.forEach((loop) => loop.stop());
      clearInterval(stepInterval);
    };
  }, [
    cardOpacityAnim,
    cardScaleAnim,
    isImporting,
    progressAnim,
    ringAnim,
    waveValues,
  ]);

  function handleInteractivePulse() {
    setBoostCount((prev) => prev + 1);
    setStepIndex((prev) => (prev + 1) % IMPORT_STEPS.length);

    orbBounceAnim.setValue(0.88);
    Animated.spring(orbBounceAnim, {
      toValue: 1,
      friction: 4,
      tension: 160,
      useNativeDriver: true,
    }).start();
  }

  async function completeProgressAndClose() {
    await new Promise<void>((resolve) => {
      Animated.timing(progressAnim, {
        toValue: 1,
        duration: 220,
        easing: Easing.out(Easing.quad),
        useNativeDriver: false,
      }).start(() => resolve());
    });
    setIsImporting(false);
  }

  async function handleImportAudio() {
    if (isImporting) return;

    const choice = await showOptions(
      "Import Audio",
      "Select where you want to import your audio recording from:",
      [
        {
          label: "Choose audio file",
          value: "file",
          icon: "document-text-outline",
        },
        {
          label: "Import from direct link",
          value: "url",
          icon: "link-outline",
        },
      ],
    );

    if (!choice) return;

    if (choice === "file") {
      try {
        const result = await DocumentPicker.getDocumentAsync({
          type: [
            "audio/*",
            "audio/mpeg",
            "audio/mp4",
            "audio/x-m4a",
            "audio/wav",
            "audio/aac",
            "audio/ogg",
          ],
          copyToCacheDirectory: true,
        });

        if (result.canceled || !result.assets || result.assets.length === 0) {
          return;
        }

        const pickedFile = result.assets[0];
        setImportSourceType("file");
        setImportLabel(pickedFile.name || "Selected audio file");
        setIsImporting(true);

        const startedAt = Date.now();

        await saveAudioImport(
          {
            uri: pickedFile.uri,
            name: pickedFile.name,
            mimeType: pickedFile.mimeType ?? undefined,
            sizeBytes: pickedFile.size ?? undefined,
          },
          addRecording,
        );

        const elapsed = Date.now() - startedAt;
        if (elapsed < 1100) {
          await delay(1100 - elapsed);
        }

        await completeProgressAndClose();

        void showAlert(
          "Audio imported",
          `"${pickedFile.name}" has been added to your VoiceNest library.`,
        );
        onImportComplete?.();
      } catch (error) {
        setIsImporting(false);
        void showAlert(
          "Import failed",
          error instanceof Error ? error.message : "Could not import the selected audio file.",
        );
      }
    } else if (choice === "url") {
      const inputUrl = await showPrompt(
        "Import from Link",
        "Enter a direct URL to an audio file (.mp3, .m4a, .wav):",
        "",
        "https://example.com/audio.mp3",
      );

      if (!inputUrl) return;

      const directUrl = extractHttpsUrl(inputUrl) || inputUrl.trim();
      const cleanName = directUrl.split("?")[0].split("/").pop() || directUrl;

      setImportSourceType("url");
      setImportLabel(cleanName);
      setIsImporting(true);

      const startedAt = Date.now();

      try {
        await importDirectAudioUrl(directUrl, addRecording);

        const elapsed = Date.now() - startedAt;
        if (elapsed < 1200) {
          await delay(1200 - elapsed);
        }

        await completeProgressAndClose();

        void showAlert(
          "Audio imported",
          "The audio file was downloaded and added to your VoiceNest library.",
        );
        onImportComplete?.();
      } catch (error) {
        setIsImporting(false);
        void showAlert(
          "Import failed",
          error instanceof Error
            ? error.message
            : "The link provided is not a valid direct audio download.",
        );
      }
    }
  }

  const ringScale = ringAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.55],
  });
  const ringOpacity = ringAnim.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [0.55, 0.25, 0],
  });
  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["8%", "100%"],
  });

  const activeStep = IMPORT_STEPS[stepIndex] ?? IMPORT_STEPS[0];

  return (
    <>
      <TouchableOpacity
        style={[styles.quickCard, { backgroundColor: colors.surfaceSage }, style]}
        onPress={() => void handleImportAudio()}
        activeOpacity={0.8}
        disabled={isImporting}
        accessibilityRole="button"
        accessibilityLabel="Import audio"
      >
        <View style={[styles.quickIcon, { backgroundColor: colors.backgroundElevated }]}>
          <Ionicons name="cloud-download-outline" size={20} color={colors.primary} />
        </View>
        <View style={styles.quickText}>
          <Text style={styles.quickTitle} numberOfLines={1}>
            Import audio
          </Text>
          <Text style={styles.quickCaption} numberOfLines={1}>
            Keep it all close
          </Text>
        </View>
      </TouchableOpacity>

      <Modal
        visible={isImporting}
        transparent
        animationType="none"
        statusBarTranslucent
        onRequestClose={() => undefined}
      >
        <View style={styles.overlayBackdrop}>
          <Animated.View
            style={[
              styles.overlayCard,
              {
                opacity: cardOpacityAnim,
                transform: [{ scale: cardScaleAnim }],
              },
            ]}
          >
            <View style={styles.topPillRow}>
              <View style={styles.liveBadge}>
                <View style={styles.liveDot} />
                <Text style={styles.liveBadgeText}>
                  {importSourceType === "url" ? "CLOUD STREAM" : "LOCAL IMPORT"}
                </Text>
              </View>
              <Text style={styles.stepCounterText}>
                Step {stepIndex + 1} of {IMPORT_STEPS.length}
              </Text>
            </View>

            <Pressable
              onPress={handleInteractivePulse}
              accessibilityRole="button"
              accessibilityLabel="Tap to pulse audio waveform"
              style={styles.orbStage}
            >
              <Animated.View
                style={[
                  styles.pulseRing,
                  {
                    transform: [{ scale: ringScale }],
                    opacity: ringOpacity,
                  },
                ]}
              />
              <Animated.View
                style={[
                  styles.waveformOrb,
                  { transform: [{ scale: orbBounceAnim }] },
                ]}
              >
                <View style={styles.waveformRow}>
                  {WAVE_BAR_HEIGHTS.map((height, index) => (
                    <Animated.View
                      key={index}
                      style={[
                        styles.waveBar,
                        {
                          height,
                          transform: [{ scaleY: waveValues[index] }],
                        },
                      ]}
                    />
                  ))}
                </View>
              </Animated.View>
            </Pressable>

            <Text style={styles.overlayTitle}>{activeStep.title}</Text>
            <Text style={styles.overlaySubtitle}>{activeStep.subtitle}</Text>

            <View style={styles.fileChip}>
              <Ionicons
                name={importSourceType === "url" ? "link-outline" : "musical-notes-outline"}
                size={15}
                color={colors.tealStrong}
              />
              <Text style={styles.fileChipText} numberOfLines={1}>
                {importLabel}
              </Text>
            </View>

            <View style={styles.progressTrack}>
              <Animated.View style={[styles.progressFill, { width: progressWidth }]} />
            </View>

            <View style={styles.stepDotsRow}>
              {IMPORT_STEPS.map((step, idx) => {
                const isDone = idx <= stepIndex;
                return (
                  <View
                    key={step.title}
                    style={[
                      styles.stepDot,
                      isDone ? styles.stepDotActive : styles.stepDotInactive,
                    ]}
                  />
                );
              })}
            </View>

            <Text style={styles.interactiveHint}>
              {boostCount > 0
                ? `Waveform synced · ${boostCount}x resonance`
                : "Tap the waveform orb while we prep your audio"}
            </Text>
          </Animated.View>
        </View>
      </Modal>

      {dialog}
    </>
  );
}

function createStyles(
  colors: Theme,
  isDark: boolean,
  responsive: ReturnType<typeof useResponsiveLayout>,
) {
  const cardShadow = isDark ? Shadows.dark.card : Shadows.light.card;
  const floatingShadow = isDark ? Shadows.dark.floating : Shadows.light.floating;

  return StyleSheet.create({
    quickCard: {
      width: responsive.width < 360 ? "100%" : "48.5%",
      minHeight: responsive.isShort ? 72 : 84,
      paddingHorizontal: responsive.isCompact ? Spacing.two : Spacing.three,
      paddingVertical: Spacing.three,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      gap: Spacing.two,
      borderWidth: 1,
      borderColor: colors.border,
      ...cardShadow,
    },
    quickIcon: {
      width: 38,
      height: 38,
      borderRadius: Radius.sm,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.border,
    },
    quickText: {
      flex: 1,
      minWidth: 0,
      justifyContent: "center",
    },
    quickTitle: {
      ...Typography.caption,
      fontFamily: Fonts?.sans,
      fontWeight: "700",
      fontSize: responsive.isCompact ? 11 : 12,
      lineHeight: 16,
      color: colors.textPrimary,
    },
    quickCaption: {
      ...Typography.caption,
      fontFamily: Fonts?.sans,
      fontSize: 10,
      lineHeight: 14,
      marginTop: 2,
      color: colors.textSecondary,
    },
    overlayBackdrop: {
      flex: 1,
      backgroundColor: colors.scrim,
      alignItems: "center",
      justifyContent: "center",
      paddingHorizontal: responsive.horizontalPadding,
    },
    overlayCard: {
      width: "100%",
      maxWidth: responsive.isTablet ? 420 : 370,
      borderRadius: Radius.xl,
      paddingHorizontal: Spacing.five,
      paddingVertical: responsive.isShort ? Spacing.four : Spacing.six,
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.borderStrong,
      alignItems: "center",
      ...floatingShadow,
    },
    topPillRow: {
      width: "100%",
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: Spacing.four,
    },
    liveBadge: {
      flexDirection: "row",
      alignItems: "center",
      gap: Spacing.one + 2,
      paddingHorizontal: Spacing.two + 2,
      paddingVertical: Spacing.one,
      borderRadius: Radius.pill,
      backgroundColor: colors.surfaceSage,
      borderWidth: 1,
      borderColor: colors.border,
    },
    liveDot: {
      width: 7,
      height: 7,
      borderRadius: Radius.pill,
      backgroundColor: colors.tealStrong,
    },
    liveBadgeText: {
      ...Typography.caption,
      fontFamily: Fonts?.sans,
      fontSize: 9,
      fontWeight: "800",
      letterSpacing: 1,
      color: colors.tealStrong,
    },
    stepCounterText: {
      ...Typography.caption,
      fontFamily: Fonts?.mono,
      fontSize: 11,
      color: colors.textTertiary,
    },
    orbStage: {
      width: responsive.isShort ? 104 : 124,
      height: responsive.isShort ? 104 : 124,
      alignItems: "center",
      justifyContent: "center",
      marginVertical: Spacing.two,
    },
    pulseRing: {
      position: "absolute",
      width: responsive.isShort ? 92 : 108,
      height: responsive.isShort ? 92 : 108,
      borderRadius: Radius.pill,
      backgroundColor: colors.surfaceSage,
      borderWidth: 1.5,
      borderColor: colors.teal,
    },
    waveformOrb: {
      width: responsive.isShort ? 88 : 104,
      height: responsive.isShort ? 88 : 104,
      borderRadius: Radius.pill,
      backgroundColor: colors.surfaceTeal,
      borderWidth: 1.5,
      borderColor: colors.borderStrong,
      alignItems: "center",
      justifyContent: "center",
      ...cardShadow,
    },
    waveformRow: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 4,
      height: 54,
    },
    waveBar: {
      width: 3.5,
      borderRadius: Radius.pill,
      backgroundColor: colors.tealStrong,
    },
    overlayTitle: {
      ...Typography.title,
      fontFamily: Fonts?.serif,
      fontSize: responsive.isCompact ? 18 : 20,
      lineHeight: 26,
      color: colors.textPrimary,
      textAlign: "center",
      marginTop: Spacing.three,
    },
    overlaySubtitle: {
      ...Typography.body,
      fontFamily: Fonts?.sans,
      fontSize: 13,
      lineHeight: 19,
      color: colors.textSecondary,
      textAlign: "center",
      marginTop: Spacing.one,
      paddingHorizontal: Spacing.two,
    },
    fileChip: {
      maxWidth: "100%",
      flexDirection: "row",
      alignItems: "center",
      gap: Spacing.two,
      marginTop: Spacing.four,
      paddingHorizontal: Spacing.three,
      paddingVertical: Spacing.two,
      borderRadius: Radius.pill,
      backgroundColor: colors.backgroundSubtle,
      borderWidth: 1,
      borderColor: colors.border,
    },
    fileChipText: {
      ...Typography.caption,
      fontFamily: Fonts?.mono,
      fontSize: 11,
      color: colors.textPrimary,
      flexShrink: 1,
    },
    progressTrack: {
      width: "100%",
      height: 6,
      borderRadius: Radius.pill,
      backgroundColor: colors.backgroundElement,
      overflow: "hidden",
      marginTop: Spacing.four,
    },
    progressFill: {
      height: "100%",
      borderRadius: Radius.pill,
      backgroundColor: colors.tealStrong,
    },
    stepDotsRow: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: Spacing.two,
      marginTop: Spacing.three,
    },
    stepDot: {
      height: 5,
      borderRadius: Radius.pill,
    },
    stepDotActive: {
      width: 22,
      backgroundColor: colors.tealStrong,
    },
    stepDotInactive: {
      width: 8,
      backgroundColor: colors.borderStrong,
    },
    interactiveHint: {
      ...Typography.caption,
      fontFamily: Fonts?.sans,
      fontSize: 11,
      color: colors.textTertiary,
      textAlign: "center",
      marginTop: Spacing.three,
    },
  });
}