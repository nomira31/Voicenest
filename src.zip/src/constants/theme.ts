import "@/global.css";

import {
  Platform,
  useColorScheme,
  type ColorSchemeName,
} from "react-native";

export const Palette = {
  ivory: "#F8F5EA",
  ivoryBright: "#FFFDF7",
  ivoryMuted: "#F1EEE2",
  ivorySoft: "#F5F1E5",

  navy: "#173C57",
  navySoft: "#214962",
  navyDeep: "#0F3048",

  teal: "#3D8583",
  tealDeep: "#2F706F",
  tealLight: "#E1EFED",

  sage: "#A9C1AE",
  sageDeep: "#85A58E",
  sageLight: "#E6EEE3",

  sky: "#B9D6D6",
  skyLight: "#E7F0EE",

  yellow: "#F4C84D",
  yellowDeep: "#EAB63A",
  yellowLight: "#FFF1C9",

  white: "#FFFDF7",
  black: "#0B1820",
} as const;

const Light = {
  text: Palette.navy,
  background: Palette.ivory,
  backgroundElement: Palette.ivoryMuted,
  backgroundSelected: "#E6EEE9",
  textSecondary: "#65747C",

  backgroundElevated: Palette.ivoryBright,
  backgroundSubtle: Palette.ivorySoft,
  surfaceYellow: Palette.yellowLight,
  surfaceTeal: Palette.tealLight,
  surfaceSage: Palette.sageLight,
  surfaceSky: Palette.skyLight,

  primary: Palette.navy,
  primaryHover: Palette.navySoft,
  primaryPressed: Palette.navyDeep,
  accent: Palette.yellow,
  accentStrong: Palette.yellowDeep,
  accentSoft: Palette.yellowLight,
  teal: Palette.teal,
  tealStrong: Palette.tealDeep,
  tealSoft: Palette.tealLight,
  sage: Palette.sage,
  sageStrong: Palette.sageDeep,
  sageSoft: Palette.sageLight,
  sky: Palette.sky,
  skySoft: Palette.skyLight,

  textPrimary: Palette.navy,
  textTertiary: "#8C999D",
  textInverse: Palette.ivoryBright,
  textOnAccent: Palette.navy,

  border: "#E5E0D3",
  borderStrong: "#D7D1C3",
  divider: "#EEE9DC",
  overlay: "rgba(23, 60, 87, 0.10)",
  scrim: "rgba(10, 30, 43, 0.52)",

  success: "#4E8A71",
  successSoft: "#E1EEE7",
  warning: "#D99D36",
  warningSoft: "#FFF0D0",
  danger: "#C86C67",
  dangerSoft: "#F7E2DF",
  info: "#5B8998",
  infoSoft: "#E2EDF1",
} as const;

const Dark = {
  ...Light,

  text: "#F7F2E5",
  background: "#0F222D",
  backgroundElement: "#1B3741",
  backgroundSelected: "#24434A",
  textSecondary: "#BBC5C5",

  backgroundElevated: "#152D38",
  backgroundSubtle: "#142A34",
  surfaceYellow: "#403619",
  surfaceTeal: "#173B3E",
  surfaceSage: "#203A31",
  surfaceSky: "#1B353A",

  primary: "#F5F0E4",
  primaryHover: "#FFF8E9",
  primaryPressed: "#E8DFCF",
  accent: Palette.yellow,
  accentStrong: "#FFD55F",
  accentSoft: "#403619",
  teal: "#67AAA7",
  tealStrong: "#82C2BE",
  tealSoft: "#1A4143",
  sage: "#ABC3AE",
  sageStrong: "#8EB09A",
  sageSoft: "#244038",
  sky: "#87B0B0",
  skySoft: "#20393E",

  textPrimary: "#F7F2E5",
  textTertiary: "#8E9D9F",
  textInverse: "#102531",
  textOnAccent: "#112F40",

  border: "#2B454E",
  borderStrong: "#3A5961",
  divider: "#233D47",
  overlay: "rgba(0, 0, 0, 0.20)",
  scrim: "rgba(0, 0, 0, 0.70)",

  success: "#78AE92",
  successSoft: "#203E32",
  warning: "#E1AD52",
  warningSoft: "#4B3D22",
  danger: "#DF8C86",
  dangerSoft: "#482927",
  info: "#83B5C2",
  infoSoft: "#223C45",
} as const;

export const Colors = {
  light: Light,
  dark: Dark,
} as const;

export type ThemeColor =
  keyof typeof Colors.light & keyof typeof Colors.dark;

export type Theme = typeof Colors.light;
export type ThemeName = keyof typeof Colors;

export const getThemeName = (
  colorScheme: ColorSchemeName,
): ThemeName => (colorScheme === "dark" ? "dark" : "light");

export const getTheme = (colorScheme: ColorSchemeName): Theme =>
  Colors[getThemeName(colorScheme)] as Theme;

export function useAppTheme(): Theme {
  const scheme = useColorScheme();
  return Colors[scheme === "dark" ? "dark" : "light"] as Theme;
}

export const Typography = {
  displayXL: {
    fontFamily: "serif",
    fontSize: 36,
    lineHeight: 42,
    fontWeight: "700",
    letterSpacing: -0.7,
  },
  display: {
    fontFamily: "serif",
    fontSize: 30,
    lineHeight: 36,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  headline: {
    fontFamily: "sans",
    fontSize: 24,
    lineHeight: 30,
    fontWeight: "700",
    letterSpacing: -0.35,
  },
  title: {
    fontFamily: "sans",
    fontSize: 19,
    lineHeight: 25,
    fontWeight: "700",
    letterSpacing: -0.15,
  },
  body: {
    fontFamily: "sans",
    fontSize: 15,
    lineHeight: 22,
    fontWeight: "400",
  },
  bodyMedium: {
    fontFamily: "sans",
    fontSize: 15,
    lineHeight: 21,
    fontWeight: "600",
  },
  label: {
    fontFamily: "sans",
    fontSize: 13,
    lineHeight: 18,
    fontWeight: "600",
    letterSpacing: 0.1,
  },
  caption: {
    fontFamily: "sans",
    fontSize: 11,
    lineHeight: 15,
    fontWeight: "500",
    letterSpacing: 0.15,
  },
  mono: {
    fontFamily: "mono",
    fontSize: 13,
    lineHeight: 18,
    fontWeight: "500",
  },
} as const;

export const Fonts = Platform.select({
  ios: {
    sans: "system-ui",
    serif: "ui-serif",
    rounded: "ui-rounded",
    mono: "ui-monospace",
  },
  default: {
    sans: "normal",
    serif: "serif",
    rounded: "normal",
    mono: "monospace",
  },
  web: {
    sans: "var(--font-display)",
    serif: "var(--font-serif)",
    rounded: "var(--font-rounded)",
    mono: "var(--font-mono)",
  },
});

export const Spacing = {
  half: 2,
  one: 4,
  two: 8,
  three: 12,
  four: 16,
  five: 20,
  six: 24,
  seven: 32,
  eight: 40,
  nine: 48,
  ten: 64,
} as const;

export const Radius = {
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 26,
  pill: 999,
} as const;

const lightCardShadow = {
  shadowColor: "#52665F",
  shadowOffset: { width: 0, height: 6 },
  shadowOpacity: 0.08,
  shadowRadius: 16,
  elevation: 3,
} as const;

const lightFloatingShadow = {
  shadowColor: "#52665F",
  shadowOffset: { width: 0, height: 10 },
  shadowOpacity: 0.12,
  shadowRadius: 24,
  elevation: 6,
} as const;

const darkCardShadow = {
  shadowColor: "#000000",
  shadowOffset: { width: 0, height: 8 },
  shadowOpacity: 0.22,
  shadowRadius: 18,
  elevation: 3,
} as const;

const darkFloatingShadow = {
  shadowColor: "#000000",
  shadowOffset: { width: 0, height: 12 },
  shadowOpacity: 0.3,
  shadowRadius: 28,
  elevation: 7,
} as const;

export const Shadows = {
  light: {
    card: lightCardShadow,
    floating: lightFloatingShadow,
  },
  dark: {
    card: darkCardShadow,
    floating: darkFloatingShadow,
  },
} as const;

export const Layout = {
  screenHorizontal: 20,
  screenHorizontalCompact: 16,
  contentMaxWidth: 800,
  controlHeight: 48,
  controlHeightLarge: 54,
  iconButton: 44,
  minTouchTarget: 44,
  bottomBarHeight: 72,
} as const;

export const BottomTabInset = Platform.select({
  ios: 50,
  android: 80,
}) ?? 0;

export const MaxContentWidth = Layout.contentMaxWidth;

