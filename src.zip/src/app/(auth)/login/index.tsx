import Ionicons from "@expo/vector-icons/Ionicons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
    Alert,
    Image,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { Radius, Spacing, useAppTheme, type Theme } from "@/constants/theme";

export default function LoginScreen() {
  const colors = useAppTheme();
  const styles = createStyles(colors);
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{
    email?: string;
    password?: string;
  }>({});

  function validateForm() {
    const nextErrors: typeof errors = {};

    if (!email.trim()) {
      nextErrors.email = "Enter your email address.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      nextErrors.email = "Enter a valid email address.";
    }

    if (!password) {
      nextErrors.password = "Enter your password.";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function handleLogin() {
    if (!validateForm()) return;

    Alert.alert(
      "Authentication not connected",
      "The login interface is ready. Connect your authentication API to sign in.",
    );
  }

  function handleForgotPassword() {
    Alert.alert(
      "Reset password",
      "Connect your password reset flow to enable account recovery.",
    );
  }

  return (
    <SafeAreaView
      style={styles.container}
      edges={["top", "bottom", "left", "right"]}
    >
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.topBar}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => router.replace("/(onboarding)/index")}
              accessibilityRole="button"
              accessibilityLabel="Back to onboarding"
            >
              <Ionicons
                name="chevron-back"
                size={21}
                color={colors.textPrimary}
              />
            </TouchableOpacity>

            <View style={styles.brand}>
              <Image
                source={require("@/assets/images/icon.png")}
                style={{ width: 40, height: 40 }}
                accessibilityLabel="VoiceNest logo"
              />

              <Text style={styles.brandName}>VoiceNest</Text>
            </View>

            <View style={styles.topBarSpacer} />
          </View>

          <View style={styles.hero}>
            <View style={styles.heroArtwork}>
              <View style={styles.orbitOuter} />
              <View style={styles.orbitInner} />

              <View style={styles.heroIcon}>
                <Ionicons
                  name="mic-outline"
                  size={35}
                  color={colors.textInverse}
                />
              </View>

              <View style={[styles.decorativeDot, styles.dotOne]} />
              <View style={[styles.decorativeDot, styles.dotTwo]} />

              <View style={styles.waveform}>
                {[15, 24, 34, 21, 42, 29, 18, 36, 23, 14].map(
                  (height, index) => (
                    <View
                      key={index}
                      style={[
                        styles.waveBar,
                        {
                          height,
                          backgroundColor:
                            index % 3 === 0 ? colors.sageStrong : colors.teal,
                        },
                      ]}
                    />
                  ),
                )}
              </View>
            </View>

            <Text style={styles.eyebrow}>YOUR VOICE, YOUR MOMENTS</Text>

            <Text style={styles.title}>Welcome back.</Text>

            <Text style={styles.description}>
              Your favourite voices and meaningful moments are waiting for you.
            </Text>
          </View>

          <View style={styles.form}>
            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Email address</Text>

              <View
                style={[
                  styles.inputContainer,
                  errors.email && styles.inputError,
                ]}
              >
                <Ionicons
                  name="mail-outline"
                  size={19}
                  color={colors.textTertiary}
                />

                <TextInput
                  style={styles.input}
                  value={email}
                  onChangeText={(value) => {
                    setEmail(value);
                    if (errors.email) {
                      setErrors((current) => ({
                        ...current,
                        email: undefined,
                      }));
                    }
                  }}
                  placeholder="you@example.com"
                  placeholderTextColor={colors.textTertiary}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                  textContentType="emailAddress"
                  autoCorrect={false}
                  returnKeyType="next"
                  accessibilityLabel="Email address"
                />
              </View>

              {errors.email ? (
                <Text style={styles.errorText}>{errors.email}</Text>
              ) : null}
            </View>

            <View style={styles.fieldGroup}>
              <View style={styles.passwordHeader}>
                <Text style={styles.fieldLabel}>Password</Text>

                <TouchableOpacity
                  onPress={handleForgotPassword}
                  accessibilityRole="button"
                >
                  <Text style={styles.forgotPassword}>Forgot password?</Text>
                </TouchableOpacity>
              </View>

              <View
                style={[
                  styles.inputContainer,
                  errors.password && styles.inputError,
                ]}
              >
                <Ionicons
                  name="lock-closed-outline"
                  size={19}
                  color={colors.textTertiary}
                />

                <TextInput
                  style={styles.input}
                  value={password}
                  onChangeText={(value) => {
                    setPassword(value);
                    if (errors.password) {
                      setErrors((current) => ({
                        ...current,
                        password: undefined,
                      }));
                    }
                  }}
                  placeholder="Enter your password"
                  placeholderTextColor={colors.textTertiary}
                  secureTextEntry={!showPassword}
                  autoComplete="current-password"
                  textContentType="password"
                  autoCapitalize="none"
                  returnKeyType="done"
                  onSubmitEditing={handleLogin}
                  accessibilityLabel="Password"
                />

                <TouchableOpacity
                  onPress={() => setShowPassword((value) => !value)}
                  hitSlop={10}
                  accessibilityRole="button"
                  accessibilityLabel={
                    showPassword ? "Hide password" : "Show password"
                  }
                >
                  <Ionicons
                    name={showPassword ? "eye-off-outline" : "eye-outline"}
                    size={19}
                    color={colors.textTertiary}
                  />
                </TouchableOpacity>
              </View>

              {errors.password ? (
                <Text style={styles.errorText}>{errors.password}</Text>
              ) : null}
            </View>

            <TouchableOpacity
              style={styles.loginButton}
              onPress={handleLogin}
              accessibilityRole="button"
            >
              <Text style={styles.loginButtonText}>Log in</Text>

              <Ionicons
                name="arrow-forward"
                size={18}
                color={colors.textInverse}
              />
            </TouchableOpacity>

            <View style={styles.dividerRow}>
              <View style={styles.divider} />
              <Text style={styles.dividerText}>A LITTLE REMINDER</Text>
              <View style={styles.divider} />
            </View>

            <View style={styles.reminderCard}>
              <View style={styles.reminderIcon}>
                <Ionicons
                  name="heart-outline"
                  size={20}
                  color={colors.tealStrong}
                />
              </View>

              <Text style={styles.reminderText}>
                You deserve to hear words that build you up.
              </Text>
            </View>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>New to VoiceNest? </Text>

            <TouchableOpacity
              onPress={() => router.push("/(auth)/signup")}
              accessibilityRole="button"
            >
              <Text style={styles.signupText}>Create an account</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.legalText}>
            By continuing, you agree to our Terms of Service and Privacy Policy.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function createStyles(colors: Theme) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    keyboardView: {
      flex: 1,
    },

    scrollContent: {
      flexGrow: 1,
      paddingHorizontal: Spacing.four,
      paddingBottom: Spacing.four,
    },

    topBar: {
      height: 48,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    backButton: {
      width: 40,
      height: 40,
      alignItems: "flex-start",
      justifyContent: "center",
    },

    brand: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
    },

    brandIcon: {
      width: 32,
      height: 32,
      borderRadius: Radius.sm,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surfaceSky,
    },

    brandName: {
      fontSize: 15,
      fontWeight: "700",
      letterSpacing: -0.3,
      color: colors.textPrimary,
    },

    topBarSpacer: {
      width: 40,
    },

    hero: {
      alignItems: "center",
      paddingTop: 8,
      paddingBottom: 24,
    },

    heroArtwork: {
      width: 190,
      height: 160,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 12,
    },

    orbitOuter: {
      position: "absolute",
      width: 142,
      height: 142,
      borderRadius: 71,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.surfaceSky,
    },

    orbitInner: {
      position: "absolute",
      width: 110,
      height: 110,
      borderRadius: 55,
      backgroundColor: colors.surfaceSage,
    },

    heroIcon: {
      width: 76,
      height: 76,
      borderRadius: 28,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.teal,
      borderWidth: 6,
      borderColor: colors.background,
    },

    waveform: {
      position: "absolute",
      bottom: 0,
      height: 40,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 4,
    },

    waveBar: {
      width: 3,
      borderRadius: Radius.pill,
    },

    decorativeDot: {
      position: "absolute",
      width: 10,
      height: 10,
      borderRadius: 5,
    },

    dotOne: {
      right: 26,
      top: 17,
      backgroundColor: colors.accent,
    },

    dotTwo: {
      left: 25,
      bottom: 34,
      backgroundColor: colors.sage,
    },

    eyebrow: {
      marginTop: 3,
      fontSize: 9,
      fontWeight: "800",
      letterSpacing: 1.5,
      textAlign: "center",
      color: colors.tealStrong,
    },

    title: {
      marginTop: 8,
      fontFamily: "serif",
      fontSize: 33,
      lineHeight: 40,
      fontWeight: "700",
      letterSpacing: -0.8,
      textAlign: "center",
      color: colors.textPrimary,
    },

    description: {
      maxWidth: 310,
      marginTop: 8,
      fontSize: 13,
      lineHeight: 21,
      textAlign: "center",
      color: colors.textSecondary,
    },

    form: {
      gap: 18,
    },

    fieldGroup: {
      gap: 8,
    },

    fieldLabel: {
      fontSize: 12,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    passwordHeader: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    forgotPassword: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.tealStrong,
    },

    inputContainer: {
      minHeight: 52,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 14,
      borderRadius: Radius.lg,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.backgroundElevated,
    },

    inputError: {
      borderColor: colors.danger,
    },

    input: {
      flex: 1,
      minWidth: 0,
      paddingVertical: 13,
      fontSize: 13,
      color: colors.textPrimary,
    },

    errorText: {
      fontSize: 11,
      color: colors.danger,
    },

    loginButton: {
      minHeight: 52,
      marginTop: 2,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 10,
      borderRadius: Radius.pill,
      backgroundColor: colors.primary,
    },

    loginButtonText: {
      fontSize: 13,
      fontWeight: "700",
      color: colors.textInverse,
    },

    dividerRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },

    divider: {
      flex: 1,
      height: 1,
      backgroundColor: colors.divider,
    },

    dividerText: {
      fontSize: 9,
      letterSpacing: 1,
      fontWeight: "700",
      color: colors.textTertiary,
    },

    reminderCard: {
      minHeight: 62,
      paddingHorizontal: 12,
      paddingVertical: 10,
      flexDirection: "row",
      alignItems: "center",
      gap: 11,
      borderRadius: Radius.lg,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.backgroundSubtle,
    },

    reminderIcon: {
      width: 36,
      height: 36,
      borderRadius: Radius.sm,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surfaceTeal,
    },

    reminderText: {
      flex: 1,
      fontSize: 11,
      lineHeight: 17,
      fontWeight: "500",
      color: colors.textSecondary,
    },

    footer: {
      marginTop: 24,
      flexDirection: "row",
      flexWrap: "wrap",
      alignItems: "center",
      justifyContent: "center",
    },

    footerText: {
      fontSize: 12,
      color: colors.textSecondary,
    },

    signupText: {
      fontSize: 12,
      fontWeight: "700",
      color: colors.tealStrong,
    },

    legalText: {
      marginTop: 13,
      paddingHorizontal: 12,
      fontSize: 9,
      lineHeight: 15,
      textAlign: "center",
      color: colors.textTertiary,
    },
  });
}
