import Ionicons from "@expo/vector-icons/Ionicons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    useWindowDimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { Radius, Spacing, useAppTheme, type Theme } from "@/constants/theme";
import { useOnboarding } from "@/contexts/onboarding-context";

const slides = [
  {
    eyebrow: "A MOMENT FOR YOU",
    title: "Step into your day with intention.",
    description:
      "Begin with words that build you, and carry them into your day.",
    icon: "sunny-outline" as const,
    note: "Make space for the words that matter.",
  },
  {
    eyebrow: "YOUR VOICE, YOUR MOMENT",
    title: "Record a message in your own voice.",
    description:
      "Keep encouragement close. Record a message you can return to whenever you need it.",
    icon: "mic-outline" as const,
    note: "Your voice, ready when you need it.",
  },
  {
    eyebrow: "ENCOURAGEMENT, ON YOUR TIME",
    title: "Let someone you trust lift you up.",
    description:
      "Invite someone you trust to record something uplifting, and decide when you want to hear it.",
    icon: "people-outline" as const,
    note: "A little encouragement goes a long way.",
  },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const colors = useAppTheme();
  const { height } = useWindowDimensions();

  const { completeOnboarding } = useOnboarding();

  const styles = createStyles(colors);
  const compact = height < 740;

  const [step, setStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currentSlide = slides[step];
  const isLastStep = step === slides.length - 1;

  async function finishOnboarding() {
    if (isSubmitting) return;

    setIsSubmitting(true);
    setError(null);

    try {
      await completeOnboarding();
      router.replace("/(auth)/login");
    } catch {
      setError("We couldn't save your progress. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleNext() {
    if (isLastStep) {
      void finishOnboarding();
      return;
    }

    setStep((current) => Math.min(current + 1, slides.length - 1));
    setError(null);
  }

  return (
    <SafeAreaView
      style={styles.container}
      edges={["top", "bottom", "left", "right"]}
    >
      <View style={styles.screen}>
        <View style={styles.topBar}>
          <View style={styles.brand}>
            <View style={styles.brandMark}>
              <Ionicons name="pulse-outline" size={19} color={colors.primary} />
            </View>

            <Text style={styles.brandName}>VoiceNest</Text>
          </View>

          {step < slides.length - 1 ? (
            <TouchableOpacity
              onPress={() => void finishOnboarding()}
              disabled={isSubmitting}
              hitSlop={10}
              accessibilityRole="button"
              accessibilityLabel="Skip onboarding"
            >
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.stepCounter}>
              <Text style={styles.stepCounterText}>
                {step + 1} of {slides.length}
              </Text>
            </View>
          )}
        </View>

        <ScrollView
          style={styles.main}
          contentContainerStyle={styles.mainContent}
          showsVerticalScrollIndicator={false}
          bounces={false}
        >
          <VoiceIllustration
            colors={colors}
            icon={currentSlide.icon}
            compact={compact}
          />

          <View style={styles.copy}>
            <Text style={styles.eyebrow}>{currentSlide.eyebrow}</Text>

            <Text style={styles.title}>{currentSlide.title}</Text>

            <Text style={styles.description}>{currentSlide.description}</Text>
          </View>

          <View style={styles.note}>
            <View style={styles.noteIcon}>
              <Ionicons
                name="volume-medium-outline"
                size={17}
                color={colors.tealStrong}
              />
            </View>

            <Text style={styles.noteText}>{currentSlide.note}</Text>
          </View>
        </ScrollView>

        <View style={styles.footer}>
          <View
            style={styles.pagination}
            accessibilityLabel={`Onboarding step ${step + 1} of ${slides.length}`}
          >
            {slides.map((slide, index) => (
              <View
                key={slide.eyebrow}
                style={[styles.dot, index === step && styles.activeDot]}
              />
            ))}
          </View>

          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          <TouchableOpacity
            style={[
              styles.primaryButton,
              isSubmitting && styles.disabledButton,
            ]}
            onPress={handleNext}
            disabled={isSubmitting}
            accessibilityRole="button"
          >
            <Text style={styles.primaryButtonText}>
              {isSubmitting
                ? "Please wait..."
                : isLastStep
                  ? "Get started"
                  : "Next"}
            </Text>

            {!isSubmitting && (
              <Ionicons
                name="arrow-forward"
                size={18}
                color={colors.textInverse}
              />
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.loginLink}
            onPress={() => void finishOnboarding()}
            disabled={isSubmitting}
            accessibilityRole="button"
          >
            <Text style={styles.loginText}>
              Already have an account?{" "}
              <Text style={styles.loginTextStrong}>Log in</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

function VoiceIllustration({
  colors,
  icon,
  compact,
}: {
  colors: Theme;
  icon: (typeof slides)[number]["icon"];
  compact: boolean;
}) {
  const styles = createStyles(colors);

  const bars = [19, 30, 17, 43, 27, 52, 32, 44, 20, 35, 48, 26, 39, 18];

  return (
    <View style={[styles.artwork, compact && styles.artworkCompact]}>
      <View
        style={[
          styles.orbitOuter,
          {
            borderColor: colors.border,
            backgroundColor: colors.surfaceSky,
          },
        ]}
      />

      <View
        style={[
          styles.orbitMiddle,
          {
            backgroundColor: colors.surfaceSage,
          },
        ]}
      />

      <View
        style={[
          styles.sun,
          {
            backgroundColor: colors.accent,
          },
        ]}
      />

      <View
        style={[
          styles.centerCircle,
          {
            backgroundColor: colors.teal,
            borderColor: colors.background,
          },
        ]}
      >
        <Ionicons name={icon} size={43} color={colors.textInverse} />
      </View>

      <View style={styles.waveform}>
        {bars.map((height, index) => (
          <View
            key={`${height}-${index}`}
            style={[
              styles.waveBar,
              {
                height: height * (compact ? 0.68 : 0.82),
                backgroundColor:
                  index % 4 === 0 ? colors.sageStrong : colors.teal,
              },
            ]}
          />
        ))}
      </View>

      <View
        style={[
          styles.floatingChip,
          styles.leftChip,
          {
            backgroundColor: colors.backgroundElevated,
            borderColor: colors.border,
          },
        ]}
      >
        <Ionicons name="heart-outline" size={19} color={colors.danger} />
      </View>

      <View
        style={[
          styles.floatingChip,
          styles.rightChip,
          {
            backgroundColor: colors.backgroundElevated,
            borderColor: colors.border,
          },
        ]}
      >
        <Ionicons name="calendar-outline" size={19} color={colors.tealStrong} />
      </View>

      <View
        style={[
          styles.floatingDot,
          styles.topDot,
          { backgroundColor: colors.accent },
        ]}
      />

      <View
        style={[
          styles.floatingDot,
          styles.bottomDot,
          { backgroundColor: colors.sage },
        ]}
      />
    </View>
  );
}

function createStyles(colors: Theme) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    screen: {
      flex: 1,
      paddingHorizontal: Spacing.four,
    },

    topBar: {
      height: 48,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    brand: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
    },

    brandMark: {
      width: 32,
      height: 32,
      borderRadius: 11,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surfaceSky,
    },

    brandName: {
      fontSize: 16,
      fontWeight: "700",
      letterSpacing: -0.3,
      color: colors.textPrimary,
    },

    skipText: {
      paddingVertical: 8,
      paddingHorizontal: 5,
      fontSize: 12,
      fontWeight: "600",
      color: colors.textSecondary,
    },

    stepCounter: {
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: Radius.pill,
      backgroundColor: colors.backgroundElement,
    },

    stepCounterText: {
      fontSize: 10,
      fontWeight: "700",
      color: colors.textSecondary,
    },

    main: {
      flex: 1,
    },

    mainContent: {
      flexGrow: 1,
      paddingTop: 8,
      paddingBottom: 16,
      justifyContent: "center",
    },

    artwork: {
      height: 235,
      marginBottom: 14,
      alignItems: "center",
      justifyContent: "center",
      position: "relative",
    },

    artworkCompact: {
      height: 185,
      marginBottom: 8,
    },

    orbitOuter: {
      width: 210,
      height: 210,
      borderRadius: 105,
      borderWidth: 1,
      position: "absolute",
      alignItems: "center",
      justifyContent: "center",
    },

    orbitMiddle: {
      width: 166,
      height: 166,
      borderRadius: 83,
      opacity: 0.85,
      position: "absolute",
    },

    sun: {
      width: 33,
      height: 33,
      borderRadius: 17,
      position: "absolute",
      right: "25%",
      top: "13%",
    },

    centerCircle: {
      width: 112,
      height: 112,
      borderRadius: 56,
      borderWidth: 7,
      alignItems: "center",
      justifyContent: "center",
    },

    waveform: {
      position: "absolute",
      bottom: 1,
      height: 54,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 5,
    },

    waveBar: {
      width: 4,
      borderRadius: 99,
    },

    floatingChip: {
      position: "absolute",
      width: 42,
      height: 42,
      borderRadius: 15,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
    },

    leftChip: {
      left: "13%",
      top: "28%",
    },

    rightChip: {
      right: "13%",
      bottom: "24%",
    },

    floatingDot: {
      position: "absolute",
      width: 9,
      height: 9,
      borderRadius: 5,
    },

    topDot: {
      left: "27%",
      top: "13%",
    },

    bottomDot: {
      right: "27%",
      bottom: "14%",
    },

    copy: {
      paddingHorizontal: 5,
    },

    eyebrow: {
      fontSize: 10,
      fontWeight: "800",
      letterSpacing: 1.5,
      color: colors.tealStrong,
      marginBottom: 9,
    },

    title: {
      fontFamily: "serif",
      fontSize: 29,
      lineHeight: 35,
      letterSpacing: -0.55,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    description: {
      marginTop: 11,
      fontSize: 13,
      lineHeight: 21,
      color: colors.textSecondary,
    },

    note: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      marginTop: 18,
      padding: 12,
      borderRadius: Radius.lg,
      backgroundColor: colors.backgroundSubtle,
      borderWidth: 1,
      borderColor: colors.border,
    },

    noteIcon: {
      width: 32,
      height: 32,
      borderRadius: 11,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surfaceTeal,
    },

    noteText: {
      flex: 1,
      fontSize: 11,
      lineHeight: 16,
      fontWeight: "600",
      color: colors.textSecondary,
    },

    footer: {
      paddingTop: 12,
      paddingBottom: 10,
    },

    pagination: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 7,
      marginBottom: 18,
    },

    dot: {
      width: 6,
      height: 6,
      borderRadius: 4,
      backgroundColor: colors.borderStrong,
    },

    activeDot: {
      width: 20,
      backgroundColor: colors.primary,
    },

    errorText: {
      textAlign: "center",
      fontSize: 11,
      lineHeight: 16,
      color: colors.danger,
      marginBottom: 10,
    },

    primaryButton: {
      minHeight: 52,
      borderRadius: Radius.pill,
      paddingHorizontal: 20,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 9,
      backgroundColor: colors.primary,
    },

    primaryButtonText: {
      fontSize: 13,
      fontWeight: "700",
      color: colors.textInverse,
    },

    disabledButton: {
      opacity: 0.65,
    },

    loginLink: {
      minHeight: 42,
      marginTop: 6,
      alignItems: "center",
      justifyContent: "center",
    },

    loginText: {
      fontSize: 11,
      color: colors.textSecondary,
    },

    loginTextStrong: {
      fontWeight: "700",
      color: colors.tealStrong,
    },
  });
}
