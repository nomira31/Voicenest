import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { View, useColorScheme } from "react-native";

import { LaunchSplash } from "@/components/launch-splash";
import { getTheme } from "@/constants/theme";
import { AuthProvider, useAuth } from "@/contexts/auth-context";
import {
  OnboardingProvider,
  useOnboarding,
} from "@/contexts/onboarding-context";

void SplashScreen.preventAutoHideAsync().catch(() => {});

export default function RootLayout() {
  return (
    <AuthProvider>
      <OnboardingProvider>
        <RootNavigator />
      </OnboardingProvider>
    </AuthProvider>
  );
}

function RootNavigator() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  const { hasCompletedOnboarding, isLoading: onboardingLoading } =
    useOnboarding();

  const scheme = useColorScheme();
  const colors = getTheme(scheme);

  if (authLoading || onboardingLoading) {
    // Keep the native splash visible until initialization finishes.
    return null;
  }

  return (
    <ThemeProvider value={scheme === "dark" ? DarkTheme : DefaultTheme}>
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
        }}
      >
        <StatusBar style={scheme === "dark" ? "light" : "dark"} />

        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="index" />

          <Stack.Protected guard={!hasCompletedOnboarding}>
            <Stack.Screen name="(onboarding)/index" />
          </Stack.Protected>

          <Stack.Protected guard={hasCompletedOnboarding && !isAuthenticated}>
            <Stack.Screen name="(auth)/login" />
          </Stack.Protected>

          <Stack.Protected guard={hasCompletedOnboarding && isAuthenticated}>
            <Stack.Screen name="(tabs)" />
          </Stack.Protected>
        </Stack>

        <LaunchSplash />
      </View>
    </ThemeProvider>
  );
}
