import Ionicons from "@expo/vector-icons/Ionicons";
import {
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { Colors, Radius, Spacing, useAppTheme } from "@/constants/theme";

type SettingsStyles = ReturnType<typeof createStyles>;

export default function SettingsScreen() {
  const colors = useAppTheme();
  const styles = createStyles(colors);

  return (
    <SafeAreaView style={styles.container} edges={["top", "left", "right"]}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.eyebrow}>PERSONALIZE</Text>
          <Text style={styles.title}>Settings</Text>
        </View>

        <TouchableOpacity style={styles.profileCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>I</Text>
          </View>

          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>Ibukun Bello</Text>

            <Text style={styles.profileEmail}>ibukun@example.com</Text>
          </View>

          <Ionicons
            name="chevron-forward"
            size={17}
            color={colors.textSecondary}
          />
        </TouchableOpacity>

        <Text style={styles.sectionLabel}>VOICE & RECORDING</Text>

        <View style={styles.settingsCard}>
          <SettingRow
            colors={colors}
            styles={styles}
            icon="mic-outline"
            surface="surfaceTeal"
            title="Recording quality"
            subtitle="High quality"
            showChevron
          />

          <SettingRow
            colors={colors}
            styles={styles}
            icon="sparkles-outline"
            surface="surfaceSky"
            title="AI transcription"
            subtitle="Automatically transcribe recordings"
            right={
              <Switch
                value
                trackColor={{
                  false: colors.borderStrong,
                  true: colors.surfaceTeal,
                }}
                thumbColor={colors.teal}
              />
            }
          />

          <SettingRow
            colors={colors}
            styles={styles}
            icon="language-outline"
            surface="surfaceSage"
            title="Transcription language"
            subtitle="English"
            showChevron
          />
        </View>

        <Text style={styles.sectionLabel}>APP</Text>

        <View style={styles.settingsCard}>
          <SettingRow
            colors={colors}
            styles={styles}
            icon="notifications-outline"
            surface="surfaceYellow"
            title="Notifications"
            subtitle="Reminders and scheduled recordings"
            showChevron
          />

          <SettingRow
            colors={colors}
            styles={styles}
            icon="moon-outline"
            surface="surfaceSky"
            title="Appearance"
            subtitle="System"
            showChevron
          />

          <SettingRow
            colors={colors}
            styles={styles}
            icon="shield-checkmark-outline"
            surface="surfaceSage"
            title="Privacy"
            subtitle="Permissions and data"
            showChevron
          />
        </View>

        <Text style={styles.sectionLabel}>SUPPORT</Text>

        <View style={styles.settingsCard}>
          <SettingRow
            colors={colors}
            styles={styles}
            icon="help-circle-outline"
            surface="surfaceTeal"
            title="Help & support"
            showChevron
          />

          <SettingRow
            colors={colors}
            styles={styles}
            icon="chatbubble-ellipses-outline"
            surface="surfaceSky"
            title="Send feedback"
            showChevron
          />

          <SettingRow
            colors={colors}
            styles={styles}
            icon="information-circle-outline"
            surface="surfaceSage"
            title="About VoiceNest"
            subtitle="Version 1.0.0"
            showChevron
          />
        </View>

        <TouchableOpacity style={styles.logoutButton}>
          <Ionicons name="log-out-outline" size={18} color={colors.danger} />

          <Text style={styles.logoutText}>Log out</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

function SettingRow({
  colors,
  styles,
  icon,
  surface,
  title,
  subtitle,
  showChevron,
  right,
}: {
  colors: typeof Colors.light;
  styles: SettingsStyles;
  icon: keyof typeof Ionicons.glyphMap;
  surface: "surfaceYellow" | "surfaceTeal" | "surfaceSage" | "surfaceSky";
  title: string;
  subtitle?: string;
  showChevron?: boolean;
  right?: React.ReactNode;
}) {
  return (
    <TouchableOpacity style={styles.settingRow}>
      <View
        style={[
          styles.settingIcon,
          {
            backgroundColor: colors[surface],
          },
        ]}
      >
        <Ionicons name={icon} size={18} color={colors.primary} />
      </View>

      <View style={styles.settingInfo}>
        <Text style={styles.settingTitle}>{title}</Text>

        {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
      </View>

      {right}

      {showChevron && (
        <Ionicons
          name="chevron-forward"
          size={17}
          color={colors.textTertiary}
        />
      )}
    </TouchableOpacity>
  );
}

function createStyles(colors: typeof Colors.light) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    content: {
      paddingHorizontal: Spacing.four,
      paddingBottom: 36,
    },

    header: {
      paddingTop: 4,
      marginBottom: 18,
    },

    eyebrow: {
      fontSize: 10,
      fontWeight: "800",
      letterSpacing: 1.5,
      color: colors.teal,
      marginBottom: 4,
    },

    title: {
      fontSize: 31,
      lineHeight: 37,
      fontWeight: "700",
      letterSpacing: -0.7,
      color: colors.textPrimary,
    },

    profileCard: {
      minHeight: 76,
      paddingHorizontal: 13,
      paddingVertical: 11,
      borderRadius: Radius.xl,
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    avatar: {
      width: 48,
      height: 48,
      borderRadius: 16,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.primary,
    },

    avatarText: {
      fontSize: 15,
      fontWeight: "800",
      color: colors.textInverse,
    },

    profileInfo: {
      flex: 1,
      marginLeft: 12,
    },

    profileName: {
      fontSize: 13,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    profileEmail: {
      marginTop: 3,
      fontSize: 10,
      color: colors.textSecondary,
    },

    sectionLabel: {
      marginTop: 24,
      marginBottom: 9,
      marginLeft: 2,
      fontSize: 9,
      fontWeight: "800",
      letterSpacing: 1.3,
      color: colors.textTertiary,
    },

    settingsCard: {
      overflow: "hidden",
      borderRadius: Radius.lg,
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    settingRow: {
      minHeight: 66,
      paddingHorizontal: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },

    settingIcon: {
      width: 37,
      height: 37,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center",
    },

    settingInfo: {
      flex: 1,
      minWidth: 0,
    },

    settingTitle: {
      fontSize: 12,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    settingSubtitle: {
      marginTop: 3,
      fontSize: 10,
      lineHeight: 14,
      color: colors.textSecondary,
    },

    logoutButton: {
      minHeight: 48,
      marginTop: 23,
      borderRadius: Radius.pill,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 7,
      backgroundColor: colors.dangerSoft,
    },

    logoutText: {
      fontSize: 12,
      fontWeight: "700",
      color: colors.danger,
    },
  });
}
