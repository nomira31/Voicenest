import Ionicons from "@expo/vector-icons/Ionicons";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { Colors, Radius, Spacing, useAppTheme } from "@/constants/theme";

const quickActions = [
  {
    id: "record",
    title: "Record",
    icon: "mic" as const,
    surface: "surfaceYellow" as const,
    iconColor: "accentStrong" as const,
  },
  {
    id: "ai",
    title: "AI Voice",
    icon: "sparkles" as const,
    surface: "surfaceSky" as const,
    iconColor: "teal" as const,
  },
  {
    id: "import",
    title: "Import",
    icon: "download-outline" as const,
    surface: "surfaceSage" as const,
    iconColor: "sageStrong" as const,
  },
  {
    id: "request",
    title: "Request",
    icon: "people-outline" as const,
    surface: "surfaceTeal" as const,
    iconColor: "tealStrong" as const,
  },
];

const upcoming = [
  {
    id: "1",
    title: "Morning Motivation",
    time: "Today, 8:00 AM",
    icon: "sunny-outline" as const,
    surface: "surfaceYellow" as const,
  },
  {
    id: "2",
    title: "A word from Mum",
    time: "Tomorrow, 7:30 AM",
    icon: "heart-outline" as const,
    surface: "surfaceSky" as const,
  },
];

export default function HomeScreen() {
  const colors = useAppTheme();
  const styles = createStyles(colors);

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={["top", "left", "right"]}>
        <ScrollView
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <View style={styles.headerText}>
              <Text style={styles.greeting}>Good morning, Ibukun</Text>

              <View style={styles.subtitleRow}>
                <Text style={styles.sun}>☀️</Text>

                <Text style={styles.subtitle}>Your voice. Your moments.</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.avatar}>
              <Text style={styles.avatarText}>I</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.searchBox}>
            <Ionicons
              name="search-outline"
              size={18}
              color={colors.textTertiary}
            />

            <Text style={styles.searchPlaceholder}>
              Search your recordings...
            </Text>
          </View>

          <View style={styles.quickActions}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                style={[
                  styles.quickCard,
                  {
                    backgroundColor: colors[action.surface],
                  },
                ]}
              >
                <View style={styles.quickIcon}>
                  <Ionicons
                    name={action.icon}
                    size={18}
                    color={colors[action.iconColor]}
                  />
                </View>

                <Text style={styles.quickTitle}>{action.title}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Upcoming</Text>

            <TouchableOpacity>
              <Text style={styles.viewAll}>View all</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.upcomingList}>
            {upcoming.map((item) => (
              <TouchableOpacity key={item.id} style={styles.upcomingCard}>
                <View
                  style={[
                    styles.upcomingIcon,
                    {
                      backgroundColor: colors[item.surface],
                    },
                  ]}
                >
                  <Ionicons
                    name={item.icon}
                    size={18}
                    color={colors.tealStrong}
                  />
                </View>

                <View style={styles.upcomingInfo}>
                  <Text style={styles.upcomingTitle}>{item.title}</Text>

                  <Text style={styles.upcomingTime}>{item.time}</Text>
                </View>

                <View style={styles.playButton}>
                  <Ionicons name="play" size={13} color={colors.primary} />
                </View>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity style={styles.recordCard}>
            <View style={styles.recordIcon}>
              <Ionicons name="mic" size={19} color={colors.textInverse} />
            </View>

            <View style={styles.recordCopy}>
              <Text style={styles.recordTitle}>Record something</Text>

              <Text style={styles.recordSubtitle}>
                Capture a thought, memory, or moment
              </Text>
            </View>

            <Ionicons
              name="chevron-forward"
              size={18}
              color={colors.textInverse}
            />
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function createStyles(colors: typeof Colors.light) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    safeArea: {
      flex: 1,
    },

    content: {
      paddingHorizontal: Spacing.four,
      paddingBottom: 34,
    },

    header: {
      paddingTop: 4,
      marginBottom: 18,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    headerText: {
      flex: 1,
      paddingRight: 12,
    },

    greeting: {
      fontSize: 23,
      lineHeight: 29,
      fontWeight: "700",
      letterSpacing: -0.35,
      color: colors.textPrimary,
    },

    subtitleRow: {
      marginTop: 4,
      flexDirection: "row",
      alignItems: "center",
    },

    sun: {
      marginRight: 5,
      fontSize: 12,
    },

    subtitle: {
      fontSize: 11,
      lineHeight: 16,
      color: colors.textSecondary,
    },

    avatar: {
      width: 40,
      height: 40,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surfaceSky,
      borderWidth: 1,
      borderColor: colors.border,
    },

    avatarText: {
      fontSize: 13,
      fontWeight: "800",
      color: colors.primary,
    },

    searchBox: {
      height: 46,
      paddingHorizontal: 14,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      gap: 9,
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    searchPlaceholder: {
      flex: 1,
      fontSize: 12,
      color: colors.textTertiary,
    },

    quickActions: {
      marginTop: 12,
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 9,
    },

    quickCard: {
      width: "48%",
      minHeight: 68,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      gap: 9,
    },

    quickIcon: {
      width: 35,
      height: 35,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundElevated,
    },

    quickTitle: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    sectionHeader: {
      marginTop: 26,
      marginBottom: 10,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    sectionTitle: {
      fontSize: 17,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    viewAll: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.tealStrong,
    },

    upcomingList: {
      gap: 8,
    },

    upcomingCard: {
      minHeight: 63,
      paddingHorizontal: 11,
      paddingVertical: 9,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    upcomingIcon: {
      width: 35,
      height: 35,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center",
      marginRight: 10,
    },

    upcomingInfo: {
      flex: 1,
    },

    upcomingTitle: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    upcomingTime: {
      marginTop: 3,
      fontSize: 9,
      color: colors.textSecondary,
    },

    playButton: {
      width: 29,
      height: 29,
      borderRadius: 10,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundSelected,
    },

    recordCard: {
      marginTop: 22,
      minHeight: 68,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderRadius: Radius.xl,
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.primary,
    },

    recordIcon: {
      width: 38,
      height: 38,
      borderRadius: 13,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.primaryHover,
    },

    recordCopy: {
      flex: 1,
      marginHorizontal: 10,
    },

    recordTitle: {
      fontSize: 12,
      fontWeight: "700",
      color: colors.textInverse,
    },

    recordSubtitle: {
      marginTop: 3,
      fontSize: 9,
      lineHeight: 13,
      color: colors.textInverse,
      opacity: 0.72,
    },
  });
}
