import Ionicons from "@expo/vector-icons/Ionicons";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { Colors, Radius, Spacing, useAppTheme } from "@/constants/theme";

const week = [
  { day: "MON", date: "12", active: false },
  { day: "TUE", date: "13", active: true },
  { day: "WED", date: "14", active: false },
  { day: "THU", date: "15", active: false },
  { day: "FRI", date: "16", active: false },
];

const upcoming = [
  {
    id: "1",
    time: "8:00 AM",
    title: "Morning Motivation",
    description: "A little encouragement to start your day.",
    repeat: "Every weekday",
    icon: "sunny-outline" as const,
    surface: "surfaceYellow" as const,
  },
  {
    id: "2",
    time: "12:30 PM",
    title: "Daily reflection",
    description: "Pause and capture what is on your mind.",
    repeat: "Every day",
    icon: "book-outline" as const,
    surface: "surfaceSage" as const,
  },
  {
    id: "3",
    time: "8:30 PM",
    title: "End-of-day reflection",
    description: "Reflect on the moments that mattered.",
    repeat: "Mon · Wed · Fri",
    icon: "moon-outline" as const,
    surface: "surfaceSky" as const,
  },
];

export default function ScheduleScreen() {
  const colors = useAppTheme();
  const styles = createStyles(colors);

  return (
    <SafeAreaView style={styles.container} edges={["top", "left", "right"]}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>YOUR ROUTINE</Text>
            <Text style={styles.title}>Schedule</Text>
          </View>

          <TouchableOpacity style={styles.addButton}>
            <Ionicons name="add" size={21} color={colors.textInverse} />
          </TouchableOpacity>
        </View>

        <View style={styles.monthHeader}>
          <Text style={styles.monthTitle}>October 2026</Text>

          <View style={styles.monthActions}>
            <TouchableOpacity style={styles.monthButton}>
              <Ionicons
                name="chevron-back"
                size={17}
                color={colors.textPrimary}
              />
            </TouchableOpacity>

            <TouchableOpacity style={styles.monthButton}>
              <Ionicons
                name="chevron-forward"
                size={17}
                color={colors.textPrimary}
              />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.weekRow}>
          {week.map((item) => (
            <TouchableOpacity key={item.date} style={styles.dayItem}>
              <Text
                style={[styles.dayLabel, item.active && styles.activeDayLabel]}
              >
                {item.day}
              </Text>

              <View
                style={[
                  styles.dateCircle,
                  item.active && styles.activeDateCircle,
                ]}
              >
                <Text
                  style={[
                    styles.dateText,
                    item.active && styles.activeDateText,
                  ]}
                >
                  {item.date}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.todayCard}>
          <View style={styles.todayIcon}>
            <Ionicons
              name="calendar-outline"
              size={17}
              color={colors.tealStrong}
            />
          </View>

          <View style={styles.todayCopy}>
            <Text style={styles.todayLabel}>TODAY</Text>

            <Text style={styles.todayText}>2 voice moments scheduled</Text>
          </View>

          <Ionicons name="checkmark-circle" size={20} color={colors.success} />
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Upcoming</Text>

          <Text style={styles.countText}>3 routines</Text>
        </View>

        <View style={styles.scheduleList}>
          {upcoming.map((item) => (
            <TouchableOpacity key={item.id} style={styles.scheduleCard}>
              <View style={styles.timeColumn}>
                <Text style={styles.time}>{item.time}</Text>
              </View>

              <View
                style={[
                  styles.scheduleIcon,
                  {
                    backgroundColor: colors[item.surface],
                  },
                ]}
              >
                <Ionicons name={item.icon} size={18} color={colors.primary} />
              </View>

              <View style={styles.scheduleInfo}>
                <Text style={styles.scheduleTitle}>{item.title}</Text>

                <Text style={styles.scheduleDescription}>
                  {item.description}
                </Text>

                <View style={styles.repeatRow}>
                  <Ionicons
                    name="repeat-outline"
                    size={12}
                    color={colors.textTertiary}
                  />

                  <Text style={styles.repeatText}>{item.repeat}</Text>
                </View>
              </View>

              <View style={styles.moreButton}>
                <Ionicons
                  name="ellipsis-vertical"
                  size={16}
                  color={colors.textTertiary}
                />
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.createButton}>
          <Ionicons
            name="add-circle-outline"
            size={18}
            color={colors.tealStrong}
          />

          <Text style={styles.createButtonText}>Create a routine</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

function createStyles(colors: typeof Colors.light) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    content: {
      paddingHorizontal: Spacing.four,
      paddingBottom: 36,
    },

    header: {
      paddingTop: 4,
      marginBottom: 22,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    eyebrow: {
      fontSize: 10,
      fontWeight: "800",
      letterSpacing: 1.5,
      color: colors.teal,
      marginBottom: 4,
    },

    title: {
      fontSize: 31,
      lineHeight: 37,
      fontWeight: "700",
      letterSpacing: -0.7,
      color: colors.textPrimary,
    },

    addButton: {
      width: 42,
      height: 42,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.primary,
    },

    monthHeader: {
      marginBottom: 15,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    monthTitle: {
      fontSize: 17,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    monthActions: {
      flexDirection: "row",
      gap: 7,
    },

    monthButton: {
      width: 35,
      height: 35,
      borderRadius: 11,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    weekRow: {
      flexDirection: "row",
      justifyContent: "space-between",
    },

    dayItem: {
      width: 57,
      alignItems: "center",
      gap: 7,
    },

    dayLabel: {
      fontSize: 9,
      fontWeight: "800",
      letterSpacing: 0.8,
      color: colors.textTertiary,
    },

    activeDayLabel: {
      color: colors.tealStrong,
    },

    dateCircle: {
      width: 42,
      height: 42,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    activeDateCircle: {
      backgroundColor: colors.teal,
      borderColor: colors.teal,
    },

    dateText: {
      fontSize: 13,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    activeDateText: {
      color: colors.textInverse,
    },

    todayCard: {
      marginTop: 22,
      minHeight: 62,
      paddingHorizontal: 12,
      paddingVertical: 9,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.surfaceTeal,
    },

    todayIcon: {
      width: 36,
      height: 36,
      borderRadius: 12,
      marginRight: 10,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundElevated,
    },

    todayCopy: {
      flex: 1,
    },

    todayLabel: {
      fontSize: 9,
      fontWeight: "800",
      letterSpacing: 1,
      color: colors.tealStrong,
    },

    todayText: {
      marginTop: 3,
      fontSize: 11,
      fontWeight: "600",
      color: colors.textPrimary,
    },

    sectionHeader: {
      marginTop: 27,
      marginBottom: 11,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    sectionTitle: {
      fontSize: 17,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    countText: {
      fontSize: 10,
      color: colors.textSecondary,
    },

    scheduleList: {
      gap: 9,
    },

    scheduleCard: {
      minHeight: 93,
      padding: 12,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "flex-start",
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    timeColumn: {
      width: 52,
      paddingTop: 3,
    },

    time: {
      fontSize: 10,
      fontWeight: "700",
      color: colors.textSecondary,
    },

    scheduleIcon: {
      width: 38,
      height: 38,
      borderRadius: 13,
      marginRight: 10,
      alignItems: "center",
      justifyContent: "center",
    },

    scheduleInfo: {
      flex: 1,
      minWidth: 0,
    },

    scheduleTitle: {
      fontSize: 12,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    scheduleDescription: {
      marginTop: 3,
      fontSize: 10,
      lineHeight: 15,
      color: colors.textSecondary,
    },

    repeatRow: {
      marginTop: 7,
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
    },

    repeatText: {
      fontSize: 9,
      color: colors.textTertiary,
    },

    moreButton: {
      width: 22,
      height: 30,
      alignItems: "center",
      justifyContent: "center",
    },

    createButton: {
      minHeight: 48,
      marginTop: 18,
      borderRadius: Radius.pill,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 7,
      backgroundColor: colors.backgroundElement,
    },

    createButtonText: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.tealStrong,
    },
  });
}
