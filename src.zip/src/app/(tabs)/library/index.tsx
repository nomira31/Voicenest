import Ionicons from "@expo/vector-icons/Ionicons";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { Radius, Spacing, useAppTheme } from "@/constants/theme";

const collections = [
  {
    title: "Morning thoughts",
    count: "12 recordings",
    icon: "sunny-outline" as const,
    surface: "surfaceYellow" as const,
  },
  {
    title: "Ideas",
    count: "8 recordings",
    icon: "bulb-outline" as const,
    surface: "surfaceSky" as const,
  },
  {
    title: "Work notes",
    count: "16 recordings",
    icon: "briefcase-outline" as const,
    surface: "surfaceSage" as const,
  },
];

const recent = [
  {
    title: "Project ideas for VoiceNest",
    date: "Today · 10:42 AM",
    duration: "04:18",
    icon: "mic-outline" as const,
    surface: "surfaceTeal" as const,
  },
  {
    title: "Things to remember",
    date: "Yesterday · 7:26 PM",
    duration: "02:41",
    icon: "heart-outline" as const,
    surface: "surfaceYellow" as const,
  },
  {
    title: "Meeting notes",
    date: "Yesterday · 2:15 PM",
    duration: "08:12",
    icon: "briefcase-outline" as const,
    surface: "surfaceSky" as const,
  },
  {
    title: "A little prayer for you",
    date: "Sep 22, 2026 · 6:15 PM",
    duration: "01:58",
    icon: "headset-outline" as const,
    surface: "surfaceSage" as const,
  },
];

export default function LibraryScreen() {
  const colors = useAppTheme();
  const styles = createStyles(colors);

  return (
    <SafeAreaView style={styles.container} edges={["top", "left", "right"]}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.headerText}>
            <Text style={styles.eyebrow}>YOUR VOICE</Text>
            <Text style={styles.title}>Library</Text>
          </View>

          <TouchableOpacity style={styles.headerButton}>
            <Ionicons
              name="search-outline"
              size={20}
              color={colors.textPrimary}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.searchBox}>
          <Ionicons
            name="search-outline"
            size={18}
            color={colors.textTertiary}
          />

          <Text style={styles.searchPlaceholder}>Search recordings</Text>

          <View style={styles.searchShortcut}>
            <Text style={styles.searchShortcutText}>⌘ K</Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Collections</Text>

          <TouchableOpacity>
            <Text style={styles.sectionAction}>See all</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.collectionRow}
        >
          {collections.map((collection) => (
            <TouchableOpacity
              key={collection.title}
              style={[
                styles.collectionCard,
                {
                  backgroundColor: colors[collection.surface],
                },
              ]}
            >
              <View style={styles.collectionTopRow}>
                <View style={styles.collectionIcon}>
                  <Ionicons
                    name={collection.icon}
                    size={18}
                    color={colors.primary}
                  />
                </View>

                <Ionicons
                  name="chevron-forward"
                  size={14}
                  color={colors.textSecondary}
                />
              </View>

              <Text style={styles.collectionTitle}>{collection.title}</Text>

              <Text style={styles.collectionCount}>{collection.count}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent recordings</Text>

          <TouchableOpacity style={styles.filterButton}>
            <Ionicons
              name="options-outline"
              size={15}
              color={colors.textPrimary}
            />

            <Text style={styles.filterText}>Filter</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.recordingList}>
          {recent.map((recording, index) => (
            <TouchableOpacity
              key={recording.title}
              style={[
                styles.recordingRow,
                index !== recent.length - 1 && styles.recordingRowBorder,
              ]}
            >
              <View
                style={[
                  styles.recordingIcon,
                  {
                    backgroundColor: colors[recording.surface],
                  },
                ]}
              >
                <Ionicons
                  name={recording.icon}
                  size={17}
                  color={colors.primary}
                />
              </View>

              <View style={styles.recordingInfo}>
                <Text style={styles.recordingTitle} numberOfLines={1}>
                  {recording.title}
                </Text>

                <Text style={styles.recordingMeta}>{recording.date}</Text>
              </View>

              <Text style={styles.duration}>{recording.duration}</Text>

              <View style={styles.moreButton}>
                <Ionicons
                  name="ellipsis-vertical"
                  size={16}
                  color={colors.textTertiary}
                />
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.newRecordingButton}>
          <Ionicons name="mic" size={18} color={colors.textInverse} />

          <Text style={styles.newRecordingText}>New recording</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

function createStyles(colors: ReturnType<typeof useAppTheme>) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    content: {
      paddingHorizontal: Spacing.four,
      paddingBottom: 36,
    },

    header: {
      paddingTop: 4,
      marginBottom: 17,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    headerText: {
      flex: 1,
    },

    eyebrow: {
      fontSize: 10,
      fontWeight: "800",
      letterSpacing: 1.5,
      color: colors.teal,
      marginBottom: 4,
    },

    title: {
      fontSize: 31,
      lineHeight: 37,
      fontWeight: "700",
      letterSpacing: -0.7,
      color: colors.textPrimary,
    },

    headerButton: {
      width: 42,
      height: 42,
      borderRadius: Radius.md,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    searchBox: {
      height: 46,
      paddingHorizontal: 14,
      borderRadius: Radius.lg,
      flexDirection: "row",
      alignItems: "center",
      gap: 9,
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    searchPlaceholder: {
      flex: 1,
      fontSize: 12,
      color: colors.textTertiary,
    },

    searchShortcut: {
      paddingHorizontal: 8,
      paddingVertical: 5,
      borderRadius: Radius.xs,
      backgroundColor: colors.backgroundElement,
    },

    searchShortcutText: {
      fontSize: 10,
      fontWeight: "600",
      color: colors.textSecondary,
    },

    sectionHeader: {
      marginTop: 25,
      marginBottom: 11,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    sectionTitle: {
      fontSize: 17,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    sectionAction: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.tealStrong,
    },

    collectionRow: {
      gap: 10,
      paddingRight: 4,
    },

    collectionCard: {
      width: 148,
      minHeight: 124,
      padding: 14,
      borderRadius: Radius.xl,
    },

    collectionTopRow: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },

    collectionIcon: {
      width: 37,
      height: 37,
      borderRadius: Radius.sm,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.backgroundElevated,
    },

    collectionTitle: {
      marginTop: 18,
      fontSize: 12,
      lineHeight: 17,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    collectionCount: {
      marginTop: 4,
      fontSize: 9,
      color: colors.textSecondary,
    },

    filterButton: {
      paddingHorizontal: 10,
      paddingVertical: 7,
      borderRadius: Radius.pill,
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      backgroundColor: colors.backgroundElement,
    },

    filterText: {
      fontSize: 10,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    recordingList: {
      overflow: "hidden",
      borderRadius: Radius.lg,
      backgroundColor: colors.backgroundElevated,
      borderWidth: 1,
      borderColor: colors.border,
    },

    recordingRow: {
      minHeight: 70,
      paddingHorizontal: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },

    recordingRowBorder: {
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },

    recordingIcon: {
      width: 38,
      height: 38,
      borderRadius: 13,
      alignItems: "center",
      justifyContent: "center",
    },

    recordingInfo: {
      flex: 1,
      minWidth: 0,
    },

    recordingTitle: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.textPrimary,
    },

    recordingMeta: {
      marginTop: 3,
      fontSize: 9,
      color: colors.textTertiary,
    },

    duration: {
      fontSize: 10,
      fontWeight: "700",
      color: colors.textSecondary,
    },

    moreButton: {
      width: 24,
      height: 32,
      alignItems: "center",
      justifyContent: "center",
    },

    newRecordingButton: {
      alignSelf: "center",
      minHeight: 48,
      marginTop: 20,
      paddingHorizontal: 19,
      borderRadius: Radius.pill,
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      backgroundColor: colors.primary,
    },

    newRecordingText: {
      fontSize: 11,
      fontWeight: "700",
      color: colors.textInverse,
    },
  });
}
