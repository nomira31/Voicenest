import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { NativeTabs } from "expo-router/unstable-native-tabs";

import { useAppTheme } from "@/constants/theme";

export default function AppTabs() {
  const colors = useAppTheme();

  return (
    <NativeTabs
      labeled
      labelVisibilityMode="labeled"
      backgroundColor={colors.backgroundElevated}
      disableIndicator
      disableTransparentOnScrollEdge
      minimizeBehavior="never"
      iconColor={{
        default: colors.textTertiary,
        selected: colors.primary,
      }}
      labelStyle={{
        default: {
          color: colors.textTertiary,
          fontSize: 10,
          fontWeight: "600",
        },
        selected: {
          color: colors.primary,
          fontSize: 10,
          fontWeight: "700",
        },
      }}
    >
      <NativeTabs.Trigger name="index">
        <NativeTabs.Trigger.Label>Home</NativeTabs.Trigger.Label>

        <NativeTabs.Trigger.Icon
          src={{
            default: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="home-outline"
              />
            ),
            selected: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="home"
              />
            ),
          }}
        />
      </NativeTabs.Trigger>

      <NativeTabs.Trigger name="library/index">
        <NativeTabs.Trigger.Label>Library</NativeTabs.Trigger.Label>

        <NativeTabs.Trigger.Icon
          src={{
            default: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="book-open-outline"
              />
            ),
            selected: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="book-open-variant"
              />
            ),
          }}
        />
      </NativeTabs.Trigger>

      <NativeTabs.Trigger name="schedule/index">
        <NativeTabs.Trigger.Label>Schedule</NativeTabs.Trigger.Label>

        <NativeTabs.Trigger.Icon
          src={{
            default: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="calendar-outline"
              />
            ),
            selected: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="calendar"
              />
            ),
          }}
        />
      </NativeTabs.Trigger>

      <NativeTabs.Trigger name="settings/index">
        <NativeTabs.Trigger.Label>Settings</NativeTabs.Trigger.Label>

        <NativeTabs.Trigger.Icon
          src={{
            default: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="account-outline"
              />
            ),
            selected: (
              <NativeTabs.Trigger.VectorIcon
                family={MaterialCommunityIcons}
                name="account"
              />
            ),
          }}
        />
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}
